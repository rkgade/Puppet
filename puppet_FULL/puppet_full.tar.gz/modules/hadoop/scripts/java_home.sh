#!/bin/bash

/bin/su -c "echo $JAVA_HOME" hadoop
